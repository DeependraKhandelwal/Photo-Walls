import React from 'react'
import Navbar2 from './Navbar2'
function AllOrders() {
    return (
        <div>
            <Navbar2/>
            <h1></h1>
        </div>
    )
}

export default AllOrders
